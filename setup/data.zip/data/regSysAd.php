<?php
// Set the value to the www directory
$ba_www="/path/to/ba_www";

require("$ba_www/config/config.php");
require("$ba_www/php/Modules.php");

req("TeacherController");

if (count($argv)<3) {
   print "Usage: $argv[0] mailaddr password";
   exit;
}
TeacherController::regSysAd($argv[1], $argv[2]);
